import { Component, OnInit } from '@angular/core';
import { NavController } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage implements OnInit {

  fromdate: any;
  todate: any;

  constructor(public http: HttpClient, public navCtrl: NavController) {

  }
  ngOnInit() {
    this.http.get("https://api.exchangeratesapi.io/history?start_at=2018-01-01&end_at=2018-09-01&symbols=USD,INR&base=USD").subscribe(resp => { console.log(resp); console.log(resp['rates'].length) }, err => console.log(err));

  }

}
