import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage implements OnInit {
  rates = [];
  data: any;
  ratesnew = [];
  rateslatest = [];
  constructor(public navCtrl: NavController, public http: HttpClient) {

  }
  getKeyByValue(object, value) {
    return Object.keys(object).find(key => object[key] === value);
  }
  ngOnInit() {

    this.http.get('https://api.exchangeratesapi.io/latest?symbols=USD,GBP').subscribe(resp => console.log(resp), err => console.log(err));
  }


  ionViewDidLoad() {
    this.http.get('https://api.exchangeratesapi.io/latest?base=USD').subscribe(data => {
      this.rates.push(data['rates']);
      for (let obj of this.rates) {
        console.log("object:", obj);
        for (let key in obj) {
          this.ratesnew.push({ "key": key, "value": obj[key] });
          //   console.log("key:", key, "value:", obj[key]);

        }
        // console.log(this.ratesnew);
        let n = this.ratesnew.length;
        for (let i = 0; i < n; i++) {
          this.rateslatest.push(this.ratesnew[i]);
        }
        console.log(this.rateslatest);

      }

      // this.rates = data;

      //  console.log(this.arrBirds[1]);

    });
    //console.log('ionViewDidLoad CurrencyPage');

  }

}
