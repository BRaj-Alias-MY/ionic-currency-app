import { Component, OnInit } from '@angular/core';
import { NavController } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage implements OnInit {
  fromval: any;
  toval: any;
  api: any;
  result: any;
  base: any;
  super: any;
  rates = [];
  data: any;
  ratesnew = [];
  rateslatest = [];
  currentval: any;
  resultnew: any;
  constructor(private http: HttpClient, public navCtrl: NavController) {

  }
  ngOnInit() {
    this.http.get('https://api.exchangeratesapi.io/latest?symbols=USD,GBP').subscribe(resp => console.log(resp), err => console.log(err));

  }

  ionViewDidLoad() {
    this.http.get('https://api.exchangeratesapi.io/latest?base=USD').subscribe(data => {
      this.rates.push(data['rates']);
      for (let obj of this.rates) {
        console.log("object:", obj);
        for (let key in obj) {
          this.ratesnew.push({ "key": key, "value": obj[key] });
          //   console.log("key:", key, "value:", obj[key]);

        }
        // console.log(this.ratesnew);
        let n = this.ratesnew.length;
        for (let i = 0; i < n; i++) {
          this.rateslatest.push(this.ratesnew[i]);
        }
        console.log(this.rateslatest);

      }

      // this.rates = data;

      //  console.log(this.arrBirds[1]);

    });
    //console.log('ionViewDidLoad CurrencyPage');

  }
  convert() {
    this.api = 'https://api.exchangeratesapi.io/latest?symbols=';
    this.api += this.fromval;
    this.api += ',';
    this.api += this.toval;
    this.api += '&base=' + this.fromval;
    console.log(this.api);
    console.log(this.fromval);
    this.http.get(this.api).subscribe(resp => {
      console.log(resp); this.result = resp; console.log(resp['rates'][this.fromval]);
      this.base = resp['rates'][this.fromval];
      this.super = resp['rates'][this.toval];
      console.log(this.currentval * resp['rates'][this.toval]);
      this.resultnew = this.currentval * resp['rates'][this.toval];

    },
      err => console.log(err));

  }

}
